﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BB_Implementor_App
{
    class BB
    {
        List<Fact> facts;
        List<Rule> rules;
        List<Action> actions;

        public BB()
        {
            // Create objects
            facts = new List<Fact>();
            rules = new List<Rule>();
            actions = new List<Action>();
        }

        public void SetFact(int FactNumber, bool FactValue)
        {
            if (facts.Exists(x => x.FactNumber == FactNumber))
                facts.Find(x => x.FactNumber == FactNumber).FactValue = FactValue;
        }

        public bool QueryFact(int FactNumber)
        {
            return facts.Find(x => x.FactNumber == FactNumber).FactValue;
        }

        public void CreateFact(int FactNumber, bool FactValue, string Description)
        {
            Fact f = new Fact();
            f.FactNumber = FactNumber;
            f.FactValue = FactValue;
            f.Description = Description;

            facts.Add(f);
        }

        public void CreateAction(int ActionNumber, string Description, string Command)
        {
            Action a = new Action();
            a.ActionNumber = ActionNumber;
            a.CommandText = Command;
            a.beentriggered = false;
            a.Description = Description;

            actions.Add(a);
        }

        public void CreateRule(int RuleNumber, int InputFact1, int InputFact2, int InputFact3, int InputFact4, int OutputFact1, int OutputFact2, int OutputFact3, int OutputFact4, int OutputAction1, int OutputAction2, int OutputAction3, int OutputAction4, string Description)
        {
            Rule r = new Rule();
            r.RuleNumber = RuleNumber;
            r.conditions = new List<ItemRecord>();
            r.triggered = new List<ItemRecord>();
            r.Description = Description;

            if (InputFact1 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = InputFact1;

                r.conditions.Add(ir);
            }

            if (InputFact2 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = InputFact2;

                r.conditions.Add(ir);
            }

            if (InputFact3 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = InputFact3;

                r.conditions.Add(ir);
            }

            if (InputFact4 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = InputFact4;

                r.conditions.Add(ir);
            }

            if (OutputFact1 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = OutputFact1;

                r.triggered.Add(ir);
            }

            if (OutputFact2 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = OutputFact2;

                r.triggered.Add(ir);
            }

            if (OutputFact3 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = OutputFact3;

                r.triggered.Add(ir);
            }

            if (OutputFact4 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'F';
                ir.Num = OutputFact4;

                r.triggered.Add(ir);
            }

            if (OutputAction1 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'A';
                ir.Num = OutputAction1;

                r.triggered.Add(ir);
            }

            if (OutputAction2 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'A';
                ir.Num = OutputAction2;

                r.triggered.Add(ir);
            }

            if (OutputAction3 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'A';
                ir.Num = OutputAction3;

                r.triggered.Add(ir);
            }

            if (OutputAction4 > 0)
            {
                ItemRecord ir = new ItemRecord();

                ir.RType = 'A';
                ir.Num = OutputAction4;

                r.triggered.Add(ir);
            }
            rules.Add(r);
        }

        private bool CheckPrereqs(Rule R)
        {
            bool prereqmet = true;

            foreach (ItemRecord ir in R.conditions)
            {
                if (facts.Find(x => x.FactNumber == ir.Num).FactValue == false)
                    prereqmet = false;
            }

            return prereqmet;
        }

        public bool RunNetwork(int TargetFact)
        {
            bool prereqmet = true;
            bool rulerun;

            do
            {
                rulerun = false;
                foreach (Rule R in rules)
                {
                    if (!R.beentriggered)
                    {
                        if (!CheckPrereqs(R))
                            prereqmet = false;

                        if (prereqmet)
                        {
                            foreach (ItemRecord ir in R.triggered)
                            {
                                runit(ir.RType, ir.Num);
                            }
                            R.beentriggered = true;
                            rulerun = true;
                        }
                    }
                }
            } while (rulerun == true);

            return facts.Find(x => x.FactNumber == TargetFact).FactValue;
        }

        public void runit(char RType, int Num)
        {
            if (RType == 'F')
            {
                facts.Find(x => x.FactNumber == Num).FactValue = true;
            }
            else if (RType == 'A')
            {
                // Get command text
                string cmdText = actions.Find(x => x.ActionNumber == Num).CommandText;

                // Run action command
                System.Threading.Thread oThread = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(ExecCmd), 0);
                oThread.IsBackground = true;
                oThread.Priority = System.Threading.ThreadPriority.AboveNormal;
                oThread.Start(cmdText);
            }
        }

        public void ExecCmd(object command)
        {
            System.Diagnostics.ProcessStartInfo PSI = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + command);
            PSI.UseShellExecute = true;

            System.Diagnostics.Process P = new System.Diagnostics.Process();

            PSI.RedirectStandardOutput = false;
            PSI.UseShellExecute = false;
            PSI.CreateNoWindow = true;

            P.StartInfo = PSI;
            P.Start();
        }
    }

    public class ItemRecord
    {
        public char RType;
        public int Num;
    }
    public class Rule
    {
        public int RuleNumber;
        public List<ItemRecord> conditions;
        public List<ItemRecord> triggered;
        public string Description;
        public bool beentriggered;
    }
    public class Action
    {
        public int ActionNumber;
        public bool beentriggered;
        public string CommandText;
        public string Description;
    }
    public class Fact
    {
        public int FactNumber;
        public bool FactValue;
        public string Description;
    }
}
