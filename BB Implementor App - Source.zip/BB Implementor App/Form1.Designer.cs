﻿
namespace BB_Implementor_App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbCommands = new System.Windows.Forms.TextBox();
            this.btnRunCommands = new System.Windows.Forms.Button();
            this.tbResults = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLoadCommandText = new System.Windows.Forms.Button();
            this.btnSaveCommandText = new System.Windows.Forms.Button();
            this.btnSaveResultsText = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbCommands
            // 
            this.tbCommands.Location = new System.Drawing.Point(259, 13);
            this.tbCommands.Multiline = true;
            this.tbCommands.Name = "tbCommands";
            this.tbCommands.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbCommands.Size = new System.Drawing.Size(1510, 403);
            this.tbCommands.TabIndex = 0;
            // 
            // btnRunCommands
            // 
            this.btnRunCommands.Location = new System.Drawing.Point(12, 326);
            this.btnRunCommands.Name = "btnRunCommands";
            this.btnRunCommands.Size = new System.Drawing.Size(241, 66);
            this.btnRunCommands.TabIndex = 1;
            this.btnRunCommands.Text = "&Run Commands";
            this.btnRunCommands.UseVisualStyleBackColor = true;
            this.btnRunCommands.Click += new System.EventHandler(this.btnRunCommands_Click);
            // 
            // tbResults
            // 
            this.tbResults.Location = new System.Drawing.Point(259, 422);
            this.tbResults.Multiline = true;
            this.tbResults.Name = "tbResults";
            this.tbResults.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbResults.Size = new System.Drawing.Size(1510, 403);
            this.tbResults.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 422);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "Results:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(218, 42);
            this.label2.TabIndex = 2;
            this.label2.Text = "Commands:";
            // 
            // btnLoadCommandText
            // 
            this.btnLoadCommandText.Location = new System.Drawing.Point(12, 77);
            this.btnLoadCommandText.Name = "btnLoadCommandText";
            this.btnLoadCommandText.Size = new System.Drawing.Size(241, 66);
            this.btnLoadCommandText.TabIndex = 3;
            this.btnLoadCommandText.Text = "&Load Command Text";
            this.btnLoadCommandText.UseVisualStyleBackColor = true;
            this.btnLoadCommandText.Click += new System.EventHandler(this.btnLoadCommandText_Click);
            // 
            // btnSaveCommandText
            // 
            this.btnSaveCommandText.Location = new System.Drawing.Point(12, 149);
            this.btnSaveCommandText.Name = "btnSaveCommandText";
            this.btnSaveCommandText.Size = new System.Drawing.Size(241, 66);
            this.btnSaveCommandText.TabIndex = 4;
            this.btnSaveCommandText.Text = "&Save Command Text";
            this.btnSaveCommandText.UseVisualStyleBackColor = true;
            this.btnSaveCommandText.Click += new System.EventHandler(this.btnSaveCommandText_Click);
            // 
            // btnSaveResultsText
            // 
            this.btnSaveResultsText.Location = new System.Drawing.Point(12, 759);
            this.btnSaveResultsText.Name = "btnSaveResultsText";
            this.btnSaveResultsText.Size = new System.Drawing.Size(241, 66);
            this.btnSaveResultsText.TabIndex = 5;
            this.btnSaveResultsText.Text = "Save &Results Text";
            this.btnSaveResultsText.UseVisualStyleBackColor = true;
            this.btnSaveResultsText.Click += new System.EventHandler(this.btnSaveResultsText_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1781, 839);
            this.Controls.Add(this.btnSaveResultsText);
            this.Controls.Add(this.btnSaveCommandText);
            this.Controls.Add(this.btnLoadCommandText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRunCommands);
            this.Controls.Add(this.tbResults);
            this.Controls.Add(this.tbCommands);
            this.Name = "Form1";
            this.Text = "BB Implementor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbCommands;
        private System.Windows.Forms.Button btnRunCommands;
        private System.Windows.Forms.TextBox tbResults;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLoadCommandText;
        private System.Windows.Forms.Button btnSaveCommandText;
        private System.Windows.Forms.Button btnSaveResultsText;
    }
}

