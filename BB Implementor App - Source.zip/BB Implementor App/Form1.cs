﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BB_Implementor_App
{
    public partial class Form1 : Form
    {
        BB BBoard;
        public Form1()
        {
            InitializeComponent();
            BBoard = new BB();
        }



        private void btnRunCommands_Click(object sender, EventArgs e)
        {
            System.IO.StringReader Read = new System.IO.StringReader(tbCommands.Text);
            string curline;
            int line = 1;
            curline = Read.ReadLine();
            ParseCommands parser = new ParseCommands(BBoard);

            while (!string.IsNullOrEmpty(curline))
            {
                ParseResult res = new ParseResult();
                res.ErrorNumber = 0;
                res.RetText = "";

                if (curline.Length > 1)
                {
                    if (curline[0] == 'F')
                        res = parser.ParseFact(curline);
                    else if (curline[0] == 'R')
                        res = parser.ParseRule(curline);
                    else if (curline[0] == 'A')
                        res = parser.ParseAction(curline);
                    else if (curline.Substring(0, 2) == "PR")
                        res = parser.ParsePresent(curline);
                    else if (curline.Substring(0, 2) == "SF")
                        res = parser.ParseSetFact(curline);
                    else if (curline.Substring(0, 2) == "QF")
                        res = parser.ParseQueryFact(curline);
                }
                else
                {
                    if (curline[0] != '*')
                    {
                        res.ErrorNumber = 200;
                        res.RetText = "Invalid Command Type Detected";
                    }
                }

                if (res.ErrorNumber > 0)
                    MessageBox.Show("Line " + line + ": ERROR: " + res.ErrorNumber + "; " + res.RetText);

                //if (res.ErrorNumber == 0)
                //{
                //    tbResults.Text = tbResults.Text + Environment.NewLine + "Result: " + res.Result;
                //}

                if (res.ErrorNumber == -2)
                {
                    tbResults.Text = tbResults.Text + Environment.NewLine + res.RetText;
                }

                curline = Read.ReadLine();
                line++;
            }

            //tbStatus.Visible = true;
            //tbStatus.Text = "Facts: " + ES.GetFactCount() + ", Rules: " + ES.GetRuleCont();
        }

        private void btnLoadCommandText_Click(object sender, EventArgs e)
        {
            System.IO.StreamReader Reader;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text files (*.txt)|*.txt";
            ofd.CheckFileExists = true;
            ofd.Multiselect = false;
            ofd.DefaultExt = "txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                Reader = new System.IO.StreamReader(ofd.FileName);
                tbCommands.Text = Reader.ReadToEnd();
                Reader.Close();
            }
        }

        private void btnSaveCommandText_Click(object sender, EventArgs e)
        {
            System.IO.StreamWriter Writer;
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text files (*.txt)|*.txt";
            sfd.DefaultExt = "txt";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                Writer = new System.IO.StreamWriter(sfd.FileName);
                Writer.Write(tbCommands.Text);
                Writer.Close();
            }
        }

        private void btnSaveResultsText_Click(object sender, EventArgs e)
        {
            System.IO.StreamWriter Writer;
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text files (*.txt)|*.txt";
            sfd.DefaultExt = "txt";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                Writer = new System.IO.StreamWriter(sfd.FileName);
                Writer.Write(tbResults.Text);
                Writer.Close();
            }
        }
    }
}
