﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BB_Implementor_App
{
    class ParseCommands
    {
        BB _BBoard;
        public ParseCommands(BB BBoard)
        {
            _BBoard = BBoard;
        }
        public ParseResult ParseFact(string InputText)
        {
            bool FormatError = false;

            int FactNumber = 0;
            char FactValue = 'F';
            string Description = "";

            if (InputText.Length > 7)
            {
                if (InputText[0] != 'F')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(1, 4), out FactNumber))
                    FormatError = true;

                if (InputText[5] != '=')
                    FormatError = true;

                if (!char.TryParse(InputText.Substring(6, 1), out FactValue))
                    FormatError = true;

                if (InputText[7] != ':')
                    FormatError = true;

                Description = InputText.Substring(8);
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.RetText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.RetText = "";
                _BBoard.CreateFact(FactNumber, FactValue == 'T', Description);
            }

            return ret;
        }

        public ParseResult ParseAction(string InputText)
        {
            bool FormatError = false;

            int ActionNumber = 0;
            string Command = "";
            string Description = "";

            if (InputText.Length > 26)
            {
                if (InputText[0] != 'A')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(1, 4), out ActionNumber))
                    FormatError = true;

                if (InputText[5] != ':')
                    FormatError = true;

                Description = InputText.Substring(6, 20);

                if (InputText[26] != ':')
                    FormatError = true;

                Command = InputText.Substring(27);
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.RetText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.RetText = "";
                _BBoard.CreateAction(ActionNumber, Description, Command);
            }

            return ret;
        }

        public ParseResult ParseRule(string InputText)
        {
            int InFact1 = 0, InFact2 = 0, InFact3 = 0, InFact4 = 0;
            int OutFact1 = 0, OutFact2 = 0, OutFact3 = 0, OutFact4 = 0;
            int OutAction1 = 0, OutAction2 = 0, OutAction3 = 0, OutAction4 = 0;
            int RuleNumber = 0;

            string Description = "";

            bool FormatError = false;
            if (InputText.Length > 54)
            {
                if (InputText[0] != 'R')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(1, 4), out RuleNumber))
                    FormatError = true;

                if (InputText[5] != ':')
                    FormatError = true;

                if (InputText[6] != 'F' && InputText[6] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[6] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(7, 4), out InFact1))
                            FormatError = true;
                    }
                    else
                        InFact1 = -1;
                }

                if (InputText[11] != '+')
                    FormatError = true;

                if (InputText[12] != 'F' && InputText[12] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[12] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(13, 4), out InFact2))
                            FormatError = true;
                    }
                    else
                        InFact2 = -1;
                }

                if (InputText[17] != '+')
                    FormatError = true;

                if (InputText[18] != 'F' && InputText[18] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[18] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(19, 4), out InFact3))
                            FormatError = true;
                    }
                    else
                        InFact3 = -1;
                }

                if (InputText[23] != '+')
                    FormatError = true;

                if (InputText[24] != 'F' && InputText[24] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[24] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(25, 4), out InFact4))
                            FormatError = true;
                    }
                    else
                        InFact4 = -1;
                }

                if (!(InputText.Substring(29, 2) == ">>"))
                    FormatError = true;

                if (InputText[31] != 'F' && InputText[31] != 'A' && InputText[31] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[31] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(32, 4), out OutFact1))
                            FormatError = true;
                        OutAction1 = -1;
                    }
                    else if (InputText[31] == 'A')
                    {
                        if (!int.TryParse(InputText.Substring(32, 4), out OutAction1))
                            FormatError = true;
                        OutFact1 = -1;
                    }
                    else
                    {
                        OutFact1 = -1;
                        OutAction1 = -1;
                    }
                }

                if (InputText[36] != '+')
                    FormatError = true;

                if (InputText[37] != 'F' && InputText[37] != 'A' && InputText[37] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[37] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(38, 4), out OutFact2))
                            FormatError = true;
                        OutAction2 = -1;
                    }
                    else if (InputText[37] == 'A')
                    {
                        if (!int.TryParse(InputText.Substring(38, 4), out OutAction2))
                            FormatError = true;
                        OutFact2 = -1;
                    }
                    else
                    {
                        OutFact2 = -1;
                        OutAction2 = -1;
                    }
                }

                if (InputText[42] != '+')
                    FormatError = true;

                if (InputText[43] != 'F' && InputText[43] != 'A' && InputText[43] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[43] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(44, 4), out OutFact3))
                            FormatError = true;
                        OutAction3 = -1;
                    }
                    else if (InputText[43] == 'A')
                    {
                        if (!int.TryParse(InputText.Substring(44, 4), out OutAction3))
                            FormatError = true;
                        OutFact3 = -1;
                    }
                    else
                    {
                        OutFact3 = -1;
                        OutAction3 = -1;
                    }
                }

                if (InputText[48] != '+')
                    FormatError = true;

                if (InputText[49] != 'F' && InputText[49] != 'A' && InputText[49] != 'N')
                    FormatError = true;
                else
                {
                    if (InputText[49] == 'F')
                    {
                        if (!int.TryParse(InputText.Substring(50, 4), out OutFact4))
                            FormatError = true;
                        OutAction4 = -1;
                    }
                    else if (InputText[49] == 'A')
                    {
                        if (!int.TryParse(InputText.Substring(50, 4), out OutAction4))
                            FormatError = true;
                        OutFact4 = -1;
                    }
                    else
                    {
                        OutFact4 = -1;
                        OutAction4 = -1;
                    }
                }

                if (InputText[54] != ':')
                    FormatError = true;

                Description = InputText.Substring(55);
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.RetText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.RetText = "";
                _BBoard.CreateRule(RuleNumber, InFact1, InFact2, InFact3, InFact4, OutFact1, OutFact2, OutFact3, OutFact4, OutAction1, OutAction2, OutAction3, OutAction4, Description);
            }

            return ret;
        }

        public ParseResult ParsePresent(string InputText)
        {
            int InFact = 0;
            int OutFact = 0;
            char InFactValue = 'F';

            bool FormatError = false;

            if (InputText.Length > 15)
            {
                if (InputText.Substring(0, 2) != "PR")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (InputText[3] != 'F')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(4, 4), out InFact))
                    FormatError = true;

                if (InputText[8] != '=')
                    FormatError = true;

                if (!char.TryParse(InputText.Substring(9,1), out InFactValue))
                    FormatError = true;

                if (InputText.Substring(10, 2) != ">>")
                    FormatError = true;

                if (InputText[12] != 'F')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(13, 4), out OutFact))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.RetText = "Format Error Detected";
            }
            else
            {
                _BBoard.SetFact(InFact, InFactValue == 'T');
                bool res = _BBoard.RunNetwork(OutFact);

                ret.ErrorNumber = -2;
                ret.RetText = "R:" + "F" + InFact.ToString("0000") + ">>F" + OutFact.ToString("0000") + ":" + res.ToString().Substring(0, 1);
                ret.Result = false;
                ret.ProcessingTime = -1;
            }

            return ret;
        }

        public ParseResult ParseSetFact(string InputText)
        {
            int FactNum = 0;
            char FactVal = 'F';

            bool FormatError = false;

            if (InputText.Length > 9)
            {
                if (InputText.Substring(0, 2) != "SF")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (InputText[3] != 'F')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(4, 4), out FactNum))
                    FormatError = true;

                if (InputText[8] != '=')
                    FormatError = true;

                if (!char.TryParse(InputText.Substring(9,1), out FactVal))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.RetText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = 0;
                ret.RetText = "";
                _BBoard.SetFact(FactNum, FactVal == 'T');
            }

            return ret;
        }

        public ParseResult ParseQueryFact(string InputText)
        {
            int FactNum = 0;

            bool FormatError = false;

            if (InputText.Length > 7)
            {
                if (InputText.Substring(0, 2) != "QF")
                    FormatError = true;

                if (InputText[2] != ':')
                    FormatError = true;

                if (InputText[3] != 'F')
                    FormatError = true;

                if (!int.TryParse(InputText.Substring(4, 4), out FactNum))
                    FormatError = true;
            }
            else
                FormatError = true;

            ParseResult ret = new ParseResult();
            if (FormatError)
            {
                ret.ErrorNumber = 100;
                ret.RetText = "Format Error Detected";
            }
            else
            {
                ret.ErrorNumber = -2;
                ret.RetText = "FV:" + "F" + FactNum.ToString("0000") + ":" + _BBoard.QueryFact(FactNum).ToString().Substring(0,1);
                ret.Result = false;
                ret.ProcessingTime = -1;
            }

            return ret;
        }
    }
}
