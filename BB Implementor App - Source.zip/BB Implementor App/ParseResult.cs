﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BB_Implementor_App
{
    class ParseResult
    {
        public int ErrorNumber; // 0 means success
        public string RetText;
        public bool Result;
        public long ProcessingTime;
    }
}
